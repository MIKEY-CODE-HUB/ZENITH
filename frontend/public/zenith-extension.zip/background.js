// ZENITH Instant Snap-Back Engine v8.0 (Zero Delay)

let activeZenithTabId = null;
let activeZenithWindowId = null;
let isSessionActive = false;
let zenithRoomUrl = null;

// Initialize state from storage on startup / wake
chrome.storage.local.get(["isFocusSessionActive", "zenithFocusUrl", "activeZenithTabId", "activeZenithWindowId"], (data) => {
  if (data && data.isFocusSessionActive) {
    isSessionActive = true;
    zenithRoomUrl = data.zenithFocusUrl;
    activeZenithTabId = data.activeZenithTabId || null;
    activeZenithWindowId = data.activeZenithWindowId || null;
  }
});

// Helper: Retrieve and verify the active ZENITH focus room tab
async function getZenithTab() {
  // 1. Try known activeZenithTabId first
  if (activeZenithTabId !== null) {
    try {
      const tab = await chrome.tabs.get(activeZenithTabId);
      if (tab && tab.url && (tab.url.includes("/focus/") && !tab.url.includes("/setup") && !tab.url.includes("/summary"))) {
        return tab;
      }
    } catch (e) {
      activeZenithTabId = null;
    }
  }

  // 2. Query all tabs for active focus room URL
  try {
    const tabs = await chrome.tabs.query({});
    const found = tabs.find(t => 
      t.url && (
        (t.url.includes("localhost:3000/focus/") ||
         t.url.includes("127.0.0.1:3000/focus/") ||
         t.url.includes("pinggy") ||
         t.url.includes("lhr.life")) &&
        t.url.includes("/focus/") &&
        !t.url.includes("/setup") &&
        !t.url.includes("/summary")
      )
    );
    if (found) {
      activeZenithTabId = found.id;
      activeZenithWindowId = found.windowId;
      isSessionActive = true;
      return found;
    }
  } catch (e) {}

  return null;
}

// Listen for messages from content scripts
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "ZENITH_ROOM_ACTIVE") {
    isSessionActive = true;
    zenithRoomUrl = msg.roomUrl;
    if (sender && sender.tab) {
      activeZenithTabId = sender.tab.id;
      activeZenithWindowId = sender.tab.windowId;
      chrome.storage.local.set({
        isFocusSessionActive: true,
        zenithFocusUrl: msg.roomUrl,
        activeZenithTabId: sender.tab.id,
        activeZenithWindowId: sender.tab.windowId
      });
    }
    sendResponse({ success: true });
  } else if (msg.type === "ZENITH_ROOM_ENDED") {
    isSessionActive = false;
    activeZenithTabId = null;
    activeZenithWindowId = null;
    zenithRoomUrl = null;
    chrome.storage.local.set({
      isFocusSessionActive: false,
      zenithFocusUrl: null,
      activeZenithTabId: null
    });
    sendResponse({ success: true });
  } else if (msg.type === "EXTERNAL_TAB_SWITCH") {
    snapBackToZenith();
  }
});

async function snapBackToZenith() {
  try {
    const zenithTab = await getZenithTab();
    if (!zenithTab) return;

    // Send attempt notification to focus room
    chrome.tabs.sendMessage(zenithTab.id, {
      type: "ZENITH_DISTRACTION_ATTEMPT",
      timestamp: Date.now()
    }).catch(() => {});

    // SNAP BACK IMMEDIATELY
    if (zenithTab.windowId) {
      chrome.windows.update(zenithTab.windowId, { focused: true }).catch(() => {});
    }
    chrome.tabs.update(zenithTab.id, { active: true }).catch(() => {});
  } catch (err) {}
}

// 1. INSTANT SNAP-BACK ON ANY TAB SWITCH (0ms Delay)
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  try {
    const zenithTab = await getZenithTab();
    if (!zenithTab) return;

    if (zenithTab.id !== activeInfo.tabId) {
      // Notify the focus room of the distraction attempt
      chrome.tabs.sendMessage(zenithTab.id, {
        type: "ZENITH_DISTRACTION_ATTEMPT",
        timestamp: Date.now()
      }).catch(() => {});

      // SNAP BACK IMMEDIATELY
      if (zenithTab.windowId) {
        chrome.windows.update(zenithTab.windowId, { focused: true }).catch(() => {});
      }
      chrome.tabs.update(zenithTab.id, { active: true }).catch(() => {});
    }
  } catch (err) {
    console.error("Instant snap error:", err);
  }
});

// 2. INSTANT SNAP-BACK ON NEW TAB CREATION
chrome.tabs.onCreated.addListener(async (newTab) => {
  try {
    const zenithTab = await getZenithTab();
    if (zenithTab && zenithTab.id !== newTab.id) {
      chrome.tabs.update(zenithTab.id, { active: true }).catch(() => {});
      if (zenithTab.windowId) {
        chrome.windows.update(zenithTab.windowId, { focused: true }).catch(() => {});
      }
    }
  } catch (err) {}
});

// 3. INSTANT SNAP-BACK ON WINDOW FOCUS LOSS
chrome.windows.onFocusChanged.addListener(async (windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) return;
  try {
    const zenithTab = await getZenithTab();
    if (zenithTab && zenithTab.windowId !== windowId) {
      chrome.windows.update(zenithTab.windowId, { focused: true }).catch(() => {});
      chrome.tabs.update(zenithTab.id, { active: true }).catch(() => {});
    }
  } catch (err) {}
});

// 4. Handle Zenith Tab Close
chrome.tabs.onRemoved.addListener((tabId) => {
  if (tabId === activeZenithTabId) {
    activeZenithTabId = null;
    isSessionActive = false;
    chrome.storage.local.set({ isFocusSessionActive: false, activeZenithTabId: null });
  }
});
