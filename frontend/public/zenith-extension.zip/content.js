// ZENITH Universal Content Guardian v8.0 (Zero Delay)

(function () {
  const currentUrl = window.location.href;
  const isZenithSite = currentUrl.includes("localhost:3000") || 
                       currentUrl.includes("127.0.0.1:3000") || 
                       currentUrl.includes("pinggy") || 
                       currentUrl.includes("lhr.life");

  // 1. IN ZENITH WEB APPLICATION
  if (isZenithSite) {
    function checkZenithState() {
      const href = window.location.href;
      const isRoom = href.includes("/focus/") && !href.includes("/setup") && !href.includes("/summary");
      if (isRoom) {
        chrome.storage.local.set({
          isFocusSessionActive: true,
          zenithFocusUrl: href,
          lastActiveTime: Date.now()
        });
        chrome.runtime.sendMessage({
          type: "ZENITH_ROOM_ACTIVE",
          roomUrl: href
        }).catch(() => {});
      } else if (href.includes("/summary") || (!href.includes("/focus/") && !href.includes("/setup"))) {
        // Only clear if session previously ended
        chrome.storage.local.get(["isFocusSessionActive"], (data) => {
          if (data.isFocusSessionActive && href.includes("/summary")) {
            chrome.storage.local.set({ isFocusSessionActive: false, zenithFocusUrl: null });
            chrome.runtime.sendMessage({ type: "ZENITH_ROOM_ENDED" }).catch(() => {});
          }
        });
      }
    }

    checkZenithState();
    setInterval(checkZenithState, 800);

    // Listen for postMessage from React components
    window.addEventListener("message", (event) => {
      if (!event.data) return;
      if (event.data.type === "ZENITH_ROOM_ACTIVE") {
        const url = event.data.roomUrl || window.location.href;
        chrome.storage.local.set({
          isFocusSessionActive: true,
          zenithFocusUrl: url,
          lastActiveTime: Date.now()
        });
        chrome.runtime.sendMessage({
          type: "ZENITH_ROOM_ACTIVE",
          roomUrl: url
        }).catch(() => {});
      } else if (event.data.type === "ZENITH_ROOM_ENDED") {
        chrome.storage.local.set({ isFocusSessionActive: false, zenithFocusUrl: null });
        chrome.runtime.sendMessage({ type: "ZENITH_ROOM_ENDED" }).catch(() => {});
      }
    });

    // Forward distraction attempt alerts from background worker to page window
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg && msg.type === "ZENITH_DISTRACTION_ATTEMPT") {
        window.postMessage({ type: "ZENITH_FOCUS_BROKEN", reason: "Tab switch detected: ZENITH pulled you back immediately." }, "*");
      }
    });

    return;
  }

  // 2. ON EXTERNAL WEBSITES DURING ACTIVE FOCUS (YouTube, Reddit, Twitter, etc.)
  if (!isZenithSite && !currentUrl.startsWith("chrome://") && !currentUrl.startsWith("chrome-extension://")) {
    chrome.storage.local.get(["isFocusSessionActive", "zenithFocusUrl"], (data) => {
      if (data.isFocusSessionActive && data.zenithFocusUrl) {
        // Freeze page
        try {
          document.querySelectorAll("video, audio").forEach(m => m.pause());
          if (document.body) document.body.style.overflow = "hidden";
        } catch (e) {}

        // Request background script to snap back to Zenith tab
        chrome.runtime.sendMessage({ type: "EXTERNAL_TAB_SWITCH" }).catch(() => {});
      }
    });
  }
})();
