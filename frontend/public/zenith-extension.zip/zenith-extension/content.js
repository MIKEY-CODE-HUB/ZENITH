// ZENITH Universal Content Guardian v7.0 (Instant Snap & Lock)

(function () {
  const currentUrl = window.location.href;
  const isZenithSite = currentUrl.includes("localhost:3000") || 
                       currentUrl.includes("127.0.0.1:3000") || 
                       currentUrl.includes("pinggy") || 
                       currentUrl.includes("lhr.life");

  // 1. In ZENITH Focus Room: sync session state
  if (isZenithSite && currentUrl.includes("/focus/") && !currentUrl.includes("/setup") && !currentUrl.includes("/summary")) {
    chrome.storage.local.set({
      isFocusSessionActive: true,
      zenithFocusUrl: currentUrl,
      lastActiveTime: Date.now()
    });

    window.addEventListener("message", (event) => {
      if (event.data && event.data.type === "ZENITH_ROOM_ENDED") {
        chrome.storage.local.set({ isFocusSessionActive: false, zenithFocusUrl: null });
      }
    });
    return;
  }

  // 2. On Any External Website during focus: INSTANT REDIRECT / SNAP BACK
  if (!isZenithSite && !currentUrl.startsWith("chrome://") && !currentUrl.startsWith("chrome-extension://")) {
    chrome.storage.local.get(["isFocusSessionActive", "zenithFocusUrl"], (data) => {
      if (data.isFocusSessionActive && data.zenithFocusUrl) {
        // Freeze page
        try {
          document.querySelectorAll("video, audio").forEach(m => m.pause());
          if (document.body) document.body.style.overflow = "hidden";
        } catch (e) {}

        // Instant push back to ZENITH Focus Room
        window.location.href = data.zenithFocusUrl;
      }
    });

    chrome.runtime.onMessage.addListener((msg) => {
      if (msg.type === "TRIGGER_FOCUS_BROKEN_LOCK") {
        window.location.href = msg.zenithFocusUrl || "http://localhost:3000/dashboard";
      }
    });
  }
})();
