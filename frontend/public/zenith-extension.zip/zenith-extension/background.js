// ZENITH Instant Snap-Back Engine v7.0 (Zero Delay)

async function findActiveZenithTab() {
  const tabs = await chrome.tabs.query({});
  return tabs.find(tab => 
    tab.url && (
      (tab.url.includes("localhost:3000/focus/") || 
       tab.url.includes("127.0.0.1:3000/focus/") || 
       tab.url.includes("lhr.life/focus/") ||
       tab.url.includes(".pinggy-free.link/focus/") ||
       tab.url.includes(".free.pinggy.net/focus/")) &&
      !tab.url.includes("/setup") && 
      !tab.url.includes("/summary")
    )
  );
}

// 1. INSTANT SNAP-BACK ON ANY TAB SWITCH (0ms Delay)
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  try {
    const zenithTab = await findActiveZenithTab();
    
    if (zenithTab && zenithTab.id !== activeInfo.tabId) {
      // Notify the focus room of the tab switch attempt
      chrome.tabs.sendMessage(zenithTab.id, {
        type: "ZENITH_DISTRACTION_ATTEMPT",
        timestamp: Date.now()
      }).catch(() => {});

      // SNAP BACK IMMEDIATELY
      await chrome.tabs.update(zenithTab.id, { active: true });
      if (zenithTab.windowId) {
        await chrome.windows.update(zenithTab.windowId, { focused: true });
      }
    }
  } catch (err) {
    console.error("Instant snap error:", err);
  }
});

// 2. INSTANT SNAP-BACK ON NEW TAB CREATION
chrome.tabs.onCreated.addListener(async (newTab) => {
  try {
    const zenithTab = await findActiveZenithTab();
    if (zenithTab && zenithTab.id !== newTab.id) {
      // Close or immediately refocus ZENITH
      chrome.tabs.update(zenithTab.id, { active: true });
      if (zenithTab.windowId) {
        chrome.windows.update(zenithTab.windowId, { focused: true });
      }
    }
  } catch (err) {}
});

// 3. INSTANT REDIRECT ON EXTERNAL NAVIGATION
chrome.webNavigation.onBeforeNavigate.addListener(async (details) => {
  if (details.frameId === 0) {
    const zenithTab = await findActiveZenithTab();
    if (zenithTab && zenithTab.id !== details.tabId) {
      const isZenith = details.url.includes("localhost:3000") || 
                       details.url.includes("127.0.0.1:3000") || 
                       details.url.includes("lhr.life") || 
                       details.url.includes("pinggy");
      
      if (!isZenith) {
        chrome.tabs.update(zenithTab.id, { active: true });
        if (zenithTab.windowId) {
          chrome.windows.update(zenithTab.windowId, { focused: true });
        }
      }
    }
  }
});

// 4. INSTANT SNAP-BACK ON WINDOW FOCUS LOSS
chrome.windows.onFocusChanged.addListener(async (windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) return;
  try {
    const zenithTab = await findActiveZenithTab();
    if (zenithTab && zenithTab.windowId !== windowId) {
      chrome.windows.update(zenithTab.windowId, { focused: true });
      chrome.tabs.update(zenithTab.id, { active: true });
    }
  } catch (err) {}
});
